import java.util.Scanner;

/*
 * Q5. Control Statement - Simple Calculator
 * Takes two numbers and an operator (+, -, *, /) and performs the
 * corresponding operation using if-else statements.
 */
public class Q5_SimpleCalculator {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter first number: ");
        double num1 = sc.nextDouble();

        System.out.print("Enter second number: ");
        double num2 = sc.nextDouble();

        System.out.print("Enter an operator (+, -, *, /): ");
        char operator = sc.next().charAt(0);

        double result;
        boolean validOperation = true;

        if (operator == '+') {
            result = num1 + num2;
        } else if (operator == '-') {
            result = num1 - num2;
        } else if (operator == '*') {
            result = num1 * num2;
        } else if (operator == '/') {
            if (num2 == 0) {
                System.out.println("Error: Division by zero is not allowed.");
                result = 0;
                validOperation = false;
            } else {
                result = num1 / num2;
            }
        } else {
            System.out.println("Error: Invalid operator entered.");
            result = 0;
            validOperation = false;
        }

        if (validOperation) {
            System.out.println("Result: " + num1 + " " + operator + " " + num2 + " = " + result);
        }

        sc.close();
    }
}
