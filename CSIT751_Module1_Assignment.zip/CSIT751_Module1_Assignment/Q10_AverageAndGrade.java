import java.util.Scanner;

/*
 * Q10. Mini Project - Average and Grade
 * Reads marks of 5 subjects into an array, calculates the average marks,
 * and assigns a grade using if-else:
 *   >= 90 : A
 *   >= 75 : B
 *   >= 50 : C
 *   else  : Fail
 */
public class Q10_AverageAndGrade {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] marks = new int[5];
        int total = 0;

        for (int i = 0; i < marks.length; i++) {
            System.out.print("Enter marks for subject " + (i + 1) + ": ");
            marks[i] = sc.nextInt();
            total += marks[i];
        }

        double average = total / (double) marks.length;
        char grade;

        if (average >= 90) {
            grade = 'A';
        } else if (average >= 75) {
            grade = 'B';
        } else if (average >= 50) {
            grade = 'C';
        } else {
            grade = 'F'; // Fail
        }

        System.out.println("\n--- Result ---");
        System.out.println("Total marks   : " + total);
        System.out.println("Average marks : " + average);
        if (grade == 'F') {
            System.out.println("Grade         : Fail");
        } else {
            System.out.println("Grade         : " + grade);
        }

        sc.close();
    }
}
