import java.util.Scanner;

/*
 * Q1. Identifier Naming Practice
 * Declares variables for a student's name, roll number, and marks in three
 * subjects, following proper Java identifier naming rules.
 */
public class Q1_IdentifierNaming {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter student name: ");
        String studentName = sc.nextLine();

        System.out.print("Enter roll number: ");
        int rollNumber = sc.nextInt();

        System.out.print("Enter marks in Subject 1: ");
        int marksSubject1 = sc.nextInt();

        System.out.print("Enter marks in Subject 2: ");
        int marksSubject2 = sc.nextInt();

        System.out.print("Enter marks in Subject 3: ");
        int marksSubject3 = sc.nextInt();

        System.out.println("\n--- Student Details ---");
        System.out.println("Name        : " + studentName);
        System.out.println("Roll Number : " + rollNumber);
        System.out.println("Subject 1   : " + marksSubject1);
        System.out.println("Subject 2   : " + marksSubject2);
        System.out.println("Subject 3   : " + marksSubject3);

        sc.close();
    }
}
