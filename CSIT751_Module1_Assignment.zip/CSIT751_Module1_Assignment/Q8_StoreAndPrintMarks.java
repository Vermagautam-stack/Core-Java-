import java.util.Scanner;

/*
 * Q8. Arrays - Store and Print Marks
 * Reads marks of 5 students into an integer array and prints each
 * student's marks.
 */
public class Q8_StoreAndPrintMarks {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] marks = new int[5];

        for (int i = 0; i < marks.length; i++) {
            System.out.print("Enter marks of student " + (i + 1) + ": ");
            marks[i] = sc.nextInt();
        }

        System.out.println("\n--- Student Marks ---");
        for (int i = 0; i < marks.length; i++) {
            System.out.println("Student " + (i + 1) + ": " + marks[i]);
        }

        sc.close();
    }
}
