import java.util.Scanner;

/*
 * Q3. Arithmetic Operations
 * Accepts two integers and performs addition, subtraction, multiplication,
 * division, and modulus.
 */
public class Q3_ArithmeticOperations {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter first integer: ");
        int num1 = sc.nextInt();

        System.out.print("Enter second integer: ");
        int num2 = sc.nextInt();

        int sum = num1 + num2;
        int difference = num1 - num2;
        int product = num1 * num2;

        System.out.println("\n--- Results ---");
        System.out.println("Addition       : " + sum);
        System.out.println("Subtraction    : " + difference);
        System.out.println("Multiplication : " + product);

        if (num2 != 0) {
            double quotient = (double) num1 / num2;
            int remainder = num1 % num2;
            System.out.println("Division       : " + quotient);
            System.out.println("Modulus        : " + remainder);
        } else {
            System.out.println("Division       : undefined (division by zero)");
            System.out.println("Modulus        : undefined (division by zero)");
        }

        sc.close();
    }
}
