import java.util.Scanner;

/*
 * Q9. Arrays and Loops - Find Maximum
 * Reads 10 integers into an array and finds the maximum value using a loop.
 */
public class Q9_FindMaximum {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] numbers = new int[10];

        for (int i = 0; i < numbers.length; i++) {
            System.out.print("Enter number " + (i + 1) + ": ");
            numbers[i] = sc.nextInt();
        }

        int max = numbers[0];
        for (int i = 1; i < numbers.length; i++) {
            if (numbers[i] > max) {
                max = numbers[i];
            }
        }

        System.out.println("The maximum value is: " + max);

        sc.close();
    }
}
