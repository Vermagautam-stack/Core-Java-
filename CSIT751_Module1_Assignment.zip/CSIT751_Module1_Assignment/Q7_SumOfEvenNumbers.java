/*
 * Q7. Loop with Conditional - Sum of Even Numbers
 * Uses a while loop to find the sum of all even numbers between 1 and 50.
 */
public class Q7_SumOfEvenNumbers {
    public static void main(String[] args) {
        int number = 1;
        int sum = 0;

        while (number <= 50) {
            if (number % 2 == 0) {
                sum += number;
            }
            number++;
        }

        System.out.println("Sum of all even numbers between 1 and 50 = " + sum);
    }
}
