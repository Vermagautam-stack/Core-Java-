CSIT751 (Core Java) - Module I: Introduction to Java
Practical Home Assignment 1 - Solutions
======================================================

This folder contains one .java file per question, matching the assignment
sheet "Practical_Home_Assignment_Module_1.pdf".

  Q1_IdentifierNaming.java       -> Q1. Identifier Naming Practice
  Q2_TemperatureConversion.java  -> Q2. Data Type Conversion (Celsius to Fahrenheit)
  Q3_ArithmeticOperations.java   -> Q3. Arithmetic Operations
  Q4_VotingEligibility.java      -> Q4. Logical Operators - Eligibility Check
  Q5_SimpleCalculator.java       -> Q5. Control Statement - Simple Calculator
  Q6_MultiplicationTable.java    -> Q6. Loop - Multiplication Table
  Q7_SumOfEvenNumbers.java       -> Q7. Loop with Conditional - Sum of Even Numbers
  Q8_StoreAndPrintMarks.java     -> Q8. Arrays - Store and Print Marks
  Q9_FindMaximum.java            -> Q9. Arrays and Loops - Find Maximum
  Q10_AverageAndGrade.java       -> Q10. Mini Project - Average and Grade

How to run each program
------------------------
1. Open a terminal in this folder.
2. Compile:   javac Q1_IdentifierNaming.java
3. Run:       java Q1_IdentifierNaming
   (Replace the file/class name for each question.)

Each program uses Scanner to take input from the console where required,
so just type the requested values when prompted and press Enter.

Notes
-----
- Class names match file names exactly, as required by Java.
- Q5 and Q3 include basic checks for division by zero and invalid input.
- Q10 uses 'F' internally to represent Fail, and prints "Fail" in the output.

You can zip/upload this whole folder directly to Google Drive as your
assignment submission.
